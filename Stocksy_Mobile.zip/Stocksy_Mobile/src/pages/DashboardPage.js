import React from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
} from "react-native";
import Button from "../components/Button";
import authService from "../../services/authService";

const StatCard = ({ label, value, change, positive }) => (
  <View style={styles.statCard}>
    <Text style={styles.statLabel}>{label}</Text>
    <Text style={styles.statValue}>{value}</Text>
    <Text style={[styles.statChange, positive ? styles.up : styles.down]}>
      {positive ? "▲" : "▼"} {change}
    </Text>
  </View>
);

const DashboardPage = ({ navigation }) => {
  const handleLogout = async () => {
    try {
      await authService.logout();
    } catch (_) {
      // ignore
    } finally {
      navigation.replace("Login");
    }
  };

  const confirmLogout = () => {
    Alert.alert("Logout", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      { text: "Logout", style: "destructive", onPress: handleLogout },
    ]);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Top Bar */}
        <View style={styles.topBar}>
          <View>
            <Text style={styles.brand}>Stocksy</Text>
            <Text style={styles.greeting}>Good morning 👋</Text>
          </View>
          <TouchableOpacity onPress={confirmLogout} style={styles.logoutBtn}>
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>

        {/* Portfolio Card */}
        <View style={styles.portfolioCard}>
          <Text style={styles.portfolioLabel}>Portfolio Value</Text>
          <Text style={styles.portfolioValue}>$24,589.50</Text>
          <Text style={styles.portfolioChange}>▲ 2.4% today</Text>
        </View>

        {/* Stats Row */}
        <Text style={styles.sectionTitle}>Overview</Text>
        <View style={styles.statsRow}>
          <StatCard label="Invested" value="$18,200" change="12.3%" positive />
          <StatCard label="P&L" value="+$6,389" change="5.1%" positive />
          <StatCard label="Today" value="-$120" change="0.4%" positive={false} />
        </View>

        {/* Watchlist placeholder */}
        <Text style={styles.sectionTitle}>Watchlist</Text>
        {["AAPL", "GOOGL", "TSLA", "AMZN"].map((ticker) => (
          <View key={ticker} style={styles.stockRow}>
            <Text style={styles.ticker}>{ticker}</Text>
            <View style={styles.stockRight}>
              <Text style={styles.stockPrice}>$---.--</Text>
              <Text style={styles.stockChange}>+0.00%</Text>
            </View>
          </View>
        ))}

        <Button
          title="Refresh Data"
          variant="outline"
          onPress={() => Alert.alert("Refresh", "Connect your API to load live data.")}
          style={styles.refreshBtn}
        />
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F8FAFC" },
  scroll: { padding: 20 },

  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 24,
  },
  brand: { fontSize: 22, fontWeight: "800", color: "#2563EB" },
  greeting: { fontSize: 13, color: "#64748B", marginTop: 2 },
  logoutBtn: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1.5,
    borderColor: "#EF4444",
  },
  logoutText: { fontSize: 13, color: "#EF4444", fontWeight: "600" },

  portfolioCard: {
    backgroundColor: "#2563EB",
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
  },
  portfolioLabel: { fontSize: 13, color: "#BFDBFE", marginBottom: 4 },
  portfolioValue: {
    fontSize: 34,
    fontWeight: "800",
    color: "#FFFFFF",
    marginBottom: 6,
  },
  portfolioChange: { fontSize: 14, color: "#86EFAC", fontWeight: "600" },

  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1E293B",
    marginBottom: 12,
  },

  statsRow: { flexDirection: "row", gap: 10, marginBottom: 24 },
  statCard: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 14,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  statLabel: { fontSize: 11, color: "#94A3B8", marginBottom: 4 },
  statValue: { fontSize: 16, fontWeight: "700", color: "#1E293B", marginBottom: 2 },
  statChange: { fontSize: 11, fontWeight: "600" },
  up: { color: "#10B981" },
  down: { color: "#EF4444" },

  stockRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    shadowColor: "#000",
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 1,
  },
  ticker: { fontSize: 15, fontWeight: "700", color: "#1E293B" },
  stockRight: { alignItems: "flex-end" },
  stockPrice: { fontSize: 14, fontWeight: "600", color: "#1E293B" },
  stockChange: { fontSize: 12, color: "#10B981", marginTop: 2 },

  refreshBtn: { marginTop: 16, marginBottom: 8 },
});

export default DashboardPage;
